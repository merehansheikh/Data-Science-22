INSERT INTO Supplier (SupplierKey, CompanyName, Address, PostalCode, CityKey)
VALUES
    (1, 'Supplier A', 'Address A', 12345, 1),
    (2, 'Supplier B', 'Address B', 67890, 2),
    (3, 'Supplier C', 'Address C', 54321, 3),
    (4, 'Supplier D', 'Address D', 98765, 4),
    (5, 'Supplier E', 'Address E', 43210, 5);