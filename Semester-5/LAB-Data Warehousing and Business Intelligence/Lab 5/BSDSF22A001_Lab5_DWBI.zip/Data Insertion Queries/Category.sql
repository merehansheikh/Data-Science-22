INSERT INTO Category (CategoryKey, CategoryName, Description)
VALUES
    (1, 'Electronics', 'Electronic gadgets and devices'),
    (2, 'Clothing', 'Apparel and accessories'),
    (3, 'Books', 'Printed books and e-books'),
    (4, 'Furniture', 'Home and office furniture'),
    (5, 'Food', 'Groceries and beverages');