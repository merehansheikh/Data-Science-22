INSERT INTO City (CityKey, CityName, StateKey, CountryKey)
VALUES
    (1, 'New York', 3, 1),
    (2, 'Los Angeles', 1, 1),
    (3, 'Chicago', 1, 1),
    (4, 'Houston', 2, 1),
    (5, 'Phoenix', 1, 1),
    (6, 'Toronto', 4, 2),
    (7, 'Montreal', 5, 2),
    (8, 'Vancouver', 4, 2),
    (9, 'London', null, 4),
    (10, 'Paris', null, 5);