INSERT INTO Product (ProductKey, ProductName, QuantityPerUnit, UnitPrice, Discontinued, CategoryKey)
VALUES
    (1, 'Laptop', 1, 800, 0, 1),
    (2, 'Smartphone', 1, 500, 0, 2),
    (3, 'Tablet', 1, 300, 0, 2),
    (4, 'Headphones', 1, 50, 0, 2),
    (5, 'Book', 1, 20, 0, 3);