INSERT INTO Sales (CustomerKey, EmployeeKey, OrderDateKey, DueDateKey, ShippedDateKey, ShipperKey, ProductKey, SupplierKey, OrderNo, OrderLineNo, UnitPrice, Quantity, Discount, SalesAmount, Freight)
VALUES
    (1, 1, 1, 2, 3, 1, 1, 1, 1001, 1, 19.99, 10, 0.1, 179.91, 10),
    (2, 2, 2, 3, 3, 2, 2, 2, 1002, 1, 29.99, 5, 0.15, 127.45, 15);