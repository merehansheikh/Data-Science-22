INSERT INTO Customer (CustomerID, CompanyName, Address, PostalCode, CityKey)
VALUES
    (1, 'Company A', 'Address A', '12345', 1),
    (2, 'Company B', 'Address B', '67890', 2),
    (3, 'Company C', 'Address C', '54321', 3),
    (4, 'Company D', 'Address D', '98765', 4),
    (5, 'Company E', 'Address E', '43210', 5);