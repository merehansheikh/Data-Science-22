INSERT INTO Territories (EmployeeKey, CityKey)
VALUES
    (1, 1),
    (1, 2),
    (2, 3),
    (2, 4),
    (3, 5),
    (3, 6);