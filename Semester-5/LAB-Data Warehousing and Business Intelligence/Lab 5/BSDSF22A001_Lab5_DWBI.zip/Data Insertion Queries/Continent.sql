INSERT INTO Continent (ContinentKey, ContinentName)
VALUES
    (1, 'Asia'),
    (2, 'Europe'),
    (3, 'Africa'),
    (4, 'North America'),
    (5, 'South America'),
    (6, 'Australia'),
    (7, 'Antarctica');