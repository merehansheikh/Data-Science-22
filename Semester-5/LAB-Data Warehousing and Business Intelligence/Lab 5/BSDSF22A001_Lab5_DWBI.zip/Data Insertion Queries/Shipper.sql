INSERT INTO Shipper (ShipperKey, CompanyName)
VALUES
    (1, 'Speedy Shipping'),
    (2, 'Reliable Express'),
    (3, 'Swift Delivery');