INSERT INTO Time (Date, DateNbWeek, DayNameWeek, DateNbMonth, DateNbYear, WeekNbYear, MonthNumber, MonthName, Quarter, Semester, Year)
VALUES
    ('2023-01-01', 1, 'Monday', 1, 1, 1, 1, 'January', 1, 1, 2023),
    ('2023-01-02', 2, 'Tuesday', 2, 2, 1, 1, 'January', 1, 1, 2023),
    ('2023-01-03', 3, 'Wednesday', 3, 3, 1, 1, 'January', 1, 1, 2023);