import streamlit as st
from statistical_comparison import perform_statistical_comparison
from ml_model import perform_ml_modeling
from eda import run_exploratory_analysis
from introduction import write_introduction
#from conclusion import write_conclusion
from streamlit_navigation_bar import st_navbar

page = st_navbar(["Introduction","Exploratory Data Analysis", "Statistical Comparison", "Machine Learning Model","Conclusion"])

if page == "Introduction":
    write_introduction()
elif page == "Exploratory Data Analysis":
    run_exploratory_analysis()
elif page == "Statistical Comparison":
    perform_statistical_comparison()
elif page == "Machine Learning Model":
    perform_ml_modeling()
#elif page == "Conclusion":
    #write_conclusion()
else:
    st.write("Oops! An error occurred. Please try again.")