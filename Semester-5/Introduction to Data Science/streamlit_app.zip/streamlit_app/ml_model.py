import streamlit as st
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV, learning_curve
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load data
try:
    data = pd.read_csv("games.csv")
except FileNotFoundError:
    st.error("Please ensure 'games.csv' is in the same directory.")
    st.stop()

def perform_ml_modeling():
    st.title("Machine Learning Model for Predicting Chess Game Winners")
    st.write("This section explores building a machine learning model to predict the winner of a chess game based on various features.")
    df = pd.DataFrame(data)
    # Feature Engineering
    df['rating_diff'] = df['white_rating'] - df['black_rating']
    df['game_duration'] = ((((df['last_move_at'] - df['created_at']) / 60) / 60) / 24)  # Convert to days

    st.write("## Data Preprocessing")
    st.write("The following steps are performed to prepare the data for modeling:")

    # Handle outliers using IQR
    def handle_outliers_iqr(df, column):
        Q1 = df[column].quantile(0.25)
        Q3 = df[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df[column] = df[column].clip(lower=lower_bound, upper=upper_bound)
        return df

    numerical_cols = ['white_rating', 'black_rating', 'turns', 'opening_ply', 'rating_diff', 'game_duration']
    for col in numerical_cols:
        df = handle_outliers_iqr(df, col)

    st.write(" - Outliers in numerical features are identified and adjusted using the Interquartile Range (IQR) method to prevent them from unduly influencing the model.")

    # Encode target variable
    le = LabelEncoder()
    df['winner'] = le.fit_transform(df['winner'])  # 0: Draw, 1: Black, 2: White
    st.write(" - The 'winner' category is encoded using Label Encoder to convert it into numerical format.")

    # Feature scaling
    numerical_cols = ['white_rating', 'black_rating', 'rating_diff', 'turns', 'opening_ply', 'game_duration']
    scaler = StandardScaler()
    df[numerical_cols] = scaler.fit_transform(df[numerical_cols])
    st.write(" - Numerical features are scaled using StandardScaler to ensure all features are on a similar scale.")


    # Model Training and Evaluation
    X = df.drop(['rated', 'opening_name', 'opening_eco', 'increment_code', 'winner', 'id', 'white_id', 'black_id', 'moves', 'created_at', 'last_move_at', 'victory_status'], axis=1)
    y = df['winner']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    st.write("## Model Training and Evaluation")

    # Hyperparameter Tuning with GridSearchCV
    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    grid_search = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=cv, scoring='accuracy', n_jobs=-1)
    grid_search.fit(X_train, y_train)
    best_model = grid_search.best_estimator_
    y_pred = best_model.predict(X_test)

    st.write(" - A Random Forest Classifier model is trained using GridSearchCV for hyperparameter tuning and StratifiedKFold cross-validation.")
    st.write(f"Best parameters found: {grid_search.best_params_}")
    st.write(f"Best cross-validation score: {grid_search.best_score_}")

    # Evaluation metrics
    st.subheader("Model Performance")
    st.write(classification_report(y_test, y_pred, target_names=le.classes_))
    cm = confusion_matrix(y_test, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=le.classes_)
    fig, ax = plt.subplots()
    disp.plot(ax=ax)
    st.pyplot(fig)
    st.write("The classification report provides key metrics such as precision, recall, F1-score, and support for each class. The confusion matrix visualizes the model's performance by showing the counts of true and predicted labels.")

    # Feature Importance
    st.subheader("Feature Importance")
    importances = best_model.feature_importances_
    feature_names = X_train.columns
    feature_importances = pd.Series(importances, index=feature_names)
    feature_importances = feature_importances.sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=feature_importances.head(20), y=feature_importances.head(20).index, ax=ax)
    ax.set_title('Top Feature Importances')
    ax.set_xlabel('Importance')
    ax.set_ylabel('Feature')
    st.pyplot(fig)
    st.write("The feature importance plot shows the relative importance of each feature in the model's predictions.")

    # Learning Curve
    st.subheader("Learning Curve")
    train_sizes, train_scores, test_scores = learning_curve(best_model, X_train, y_train, cv=cv, scoring='accuracy', train_sizes=np.linspace(0.1, 1.0, 10), n_jobs=-1)

    train_mean = np.mean(train_scores, axis=1)
    train_std = np.std(train_scores, axis=1)
    test_mean = np.mean(test_scores, axis=1)
    test_std = np.std(test_scores, axis=1)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(train_sizes, train_mean, label="Training score")
    ax.plot(train_sizes, test_mean, label="Cross-validation score")
    ax.fill_between(train_sizes, train_mean - train_std, train_mean + train_std, alpha=0.1)
    ax.fill_between(train_sizes, test_mean - test_std, test_mean + test_std, alpha=0.1)
    ax.set_title("Learning Curve")
    ax.set_xlabel("Training Set Size")
    ax.set_ylabel("Accuracy Score")
    ax.legend(loc="best")
    st.pyplot(fig)
    st.write("The learning curve shows how the model's performance changes with increasing amounts of training data. It can help diagnose overfitting or underfitting.")

if __name__ == "__main__":
    import streamlit as st
    perform_ml_modeling()