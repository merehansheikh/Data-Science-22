import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data (assuming the CSV is accessible locally)
try:
    df = pd.read_csv("games.csv")
except FileNotFoundError:
    st.error("Please ensure 'games.csv' is located in the same directory as this script.")
    st.stop()

def perform_statistical_comparison():
    st.title("Statistical Comparison of White and Black Wins")
    st.write("This section compares various aspects of games won by white and black players.")

    white_wins = df[df['winner'] == 'white']
    black_wins = df[df['winner'] == 'black']

    # Total Games Won (Bar Chart)
    total_games = {'White Wins': len(white_wins), 'Black Wins': len(black_wins)}
    labels = list(total_games.keys())
    values = list(total_games.values())

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.bar(labels, values, color=['lightgray', 'black']) #Improved color contrast
    ax.set_title('Total Games Won')
    ax.set_ylabel('Number of Games')
    st.pyplot(fig)
    st.write("This chart shows the number of games won by white and black. It gives a sense of the overall balance (or imbalance) in wins between the two sides.")

    # Distribution of Moves (Box Plot)
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.boxplot([white_wins['turns'], black_wins['turns']], labels=['White Wins', 'Black Wins'], notch=True)
    ax.set_title('Distribution of Moves')
    ax.set_ylabel('Number of Moves')
    st.pyplot(fig)
    st.write("The box plot compares the distribution of the number of turns in games won by white and black. The box shows the interquartile range (IQR), the line inside the box is the median, and the whiskers extend to 1.5 times the IQR. Outliers are shown as individual points. 'Notch=True' provides a visual indication of whether the medians of the two groups are significantly different.")

    # Distribution of Moves (Histogram)
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.hist(white_wins['turns'], bins=20, alpha=0.5, label='White Wins', color='lightgray') #Improved color contrast
    ax.hist(black_wins['turns'], bins=20, alpha=0.5, label='Black Wins', color='black')
    ax.set_title('Number of Moves Distribution')
    ax.set_xlabel('Number of Moves')
    ax.set_ylabel('Frequency')
    ax.legend()
    st.pyplot(fig)
    st.write("The histogram shows the frequency of games with different numbers of turns, separated by the winner. This gives a more detailed view of the distribution than the box plot.")

    # Rating Statistics
    for color in ['white', 'black']:
        winner_df = df[df['winner'] == color]
        opponent_color = 'black' if color == 'white' else 'white'
        ratings = {
            'Min': winner_df[f'{color}_rating'].min(),
            'Max': winner_df[f'{color}_rating'].max(),
            'Avg': winner_df[f'{color}_rating'].mean()
        }
        fig, ax = plt.subplots(figsize=(6, 5))
        ax.bar(ratings.keys(), ratings.values(), color='lightgray' if color == 'white' else 'black') #Improved color contrast
        ax.set_title(f'{color.capitalize()} Ratings ({color.capitalize()} Wins)')
        ax.set_ylabel('Rating')
        st.pyplot(fig)
        st.write(f"These statistics show the distribution of {color} player ratings when {color} wins.")

        opponent_ratings = {
            'Min': winner_df[f'{opponent_color}_rating'].min(),
            'Max': winner_df[f'{opponent_color}_rating'].max(),
            'Avg': winner_df[f'{opponent_color}_rating'].mean()
        }
        fig, ax = plt.subplots(figsize=(6, 5))
        ax.bar(opponent_ratings.keys(), opponent_ratings.values(), color='black' if color == 'white' else 'lightgray') #Improved color contrast
        ax.set_title(f'{opponent_color.capitalize()} Ratings ({color.capitalize()} Wins)')
        ax.set_ylabel('Rating')
        st.pyplot(fig)
        st.write(f"These statistics show the distribution of {opponent_color} player ratings when {color} wins.")

    # Violin Plots (Combined Data)
    combined = pd.concat([white_wins.assign(Result='White Wins'), black_wins.assign(Result='Black Wins')]) #More efficient concatenation
    fig, ax = plt.subplots()
    sns.violinplot(x='Result', y='white_rating', data=combined, palette=['lightgray', 'black'], ax=ax) #Improved color contrast
    ax.set_title('White Ratings Distribution by Result')
    st.pyplot(fig)
    st.write("The violin plot shows the distribution of white player ratings, separated by whether white won or lost. It combines aspects of box plots and kernel density estimation to show the distribution's shape, median, and quartiles.")

    fig, ax = plt.subplots()
    sns.violinplot(x='Result', y='black_rating', data=combined, palette=['lightgray', 'black'], ax=ax) #Improved color contrast
    ax.set_title('Black Ratings Distribution by Result')
    st.pyplot(fig)
    st.write("The violin plot shows the distribution of black player ratings, separated by whether black won or lost. It combines aspects of box plots and kernel density estimation to show the distribution's shape, median, and quartiles.")

if __name__ == "__main__":
    import streamlit as st
    perform_statistical_comparison()