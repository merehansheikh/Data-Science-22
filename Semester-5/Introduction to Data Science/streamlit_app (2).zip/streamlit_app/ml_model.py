import streamlit as st
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from time import time
import numpy as np

# Load data
@st.cache_data
def load_data():
    try:
        df = pd.read_csv("games.csv")
        return df
    except FileNotFoundError:
        st.error("Please ensure 'games.csv' is in the same directory.")
        st.stop()

# Preprocess data
@st.cache_data
def preprocess_data(df):
    # Feature Engineering
    df['rating_diff'] = df['white_rating'] - df['black_rating']
    df['game_duration'] = ((((df['last_move_at'] - df['created_at']) / 60) / 60) / 24)  # Convert to days

    def handle_outliers_iqr(df, column):
        Q1 = df[column].quantile(0.25)
        Q3 = df[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df[column] = df[column].clip(lower=lower_bound, upper=upper_bound)
        return df

    numerical_cols = ['white_rating', 'black_rating', 'turns', 'opening_ply', 'rating_diff', 'game_duration']
    for col in numerical_cols:
        df = handle_outliers_iqr(df, col)

    le = LabelEncoder()
    df['winner'] = le.fit_transform(df['winner'])  # 0: Draw, 1: Black, 2: White

    scaler = StandardScaler()
    df[numerical_cols] = scaler.fit_transform(df[numerical_cols])

    return df, le, scaler

# Train and save the model with progress bar
def train_and_save_optimized_model(X_train, y_train, model_path='optimized_chess_model.pkl'):
    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [None, 10, 20, 30],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
    }

    rf = RandomForestClassifier(random_state=42)
    grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)
    
    # Progress bar
    progress_bar = st.progress(0)
    st.write("Training model with GridSearchCV... Please wait.")
    
    for percent_complete in range(0, 101, 10):
        time.sleep(0.5)  # Simulating progress (remove or adjust based on real training time)
        progress_bar.progress(percent_complete)
    
    grid_search.fit(X_train, y_train)

    # Save the best model
    best_model = grid_search.best_estimator_
    with open(model_path, 'wb') as f:
        pickle.dump(best_model, f)

    st.success("Optimized model training completed and saved to 'optimized_chess_model.pkl'!")
    st.write("Best Parameters:", grid_search.best_params_)

# Load pre-trained model
def load_model(model_path='optimized_chess_model.pkl'):
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        st.success("Pre-trained model loaded successfully!")
        return model
    except FileNotFoundError:
        st.error(f"No pre-trained model found at {model_path}. Train and save the model first.")
        st.stop()

# Visualize confusion matrix
def plot_confusion_matrix(y_test, y_pred, class_names):
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix")
    st.pyplot(fig)

# Feature importance visualization
def plot_feature_importance(model, feature_names):
    importance = model.feature_importances_
    importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': importance})
    importance_df = importance_df.sort_values(by='Importance', ascending=False)

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=importance_df, palette='viridis')
    plt.title("Feature Importance")
    st.pyplot(fig)

# Perform ML modeling and predictions
def perform_ml_modeling():
    st.title("Machine Learning Model - Chess Outcome Prediction (Optimized)")

    # Load and preprocess data
    df = load_data()
    df, le, scaler = preprocess_data(df)

    # Prepare data for training and testing
    X = df.drop(['rated', 'opening_name', 'opening_eco', 'increment_code', 'winner', 'id', 'white_id', 'black_id', 'moves', 'created_at', 'last_move_at', 'victory_status'], axis=1)
    y = df['winner']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    model_path = 'optimized_chess_model.pkl'

    # Train and save the model
    if st.button("Train and Save Optimized Model"):
        train_and_save_optimized_model(X_train, y_train, model_path)

    st.write("If you've already trained the optimized model, you can load it for predictions.")
    
    # Load pre-trained model and predict
    if st.button("Load Pre-Trained Model"):
        model = load_model(model_path)
        y_pred = model.predict(X_test)

        st.write("### Model Evaluation")
        st.write("Accuracy:", accuracy_score(y_test, y_pred))
        st.write("Classification Report:")
        st.text(classification_report(y_test, y_pred, target_names=le.classes_))

        # Visualizations
        st.write("### Confusion Matrix")
        plot_confusion_matrix(y_test, y_pred, class_names=le.classes_)

        st.write("### Feature Importance")
        plot_feature_importance(model, X.columns)
