import streamlit as st

def show(data):
    st.title("Conclusion")
    st.markdown("""
    In this analysis, we explored 20,000 chess games, performed EDA, conducted statistical analyses, and built a machine learning model to predict game outcomes. The insights gained provide a deeper understanding of chess strategies and player behaviors. Future work could involve analyzing larger datasets, exploring different features, and improving model performance.
    """)
